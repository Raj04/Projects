

//for button press
var doc=document.getElementsByClassName("drum");

for(var i=0;i<doc.length;i++){
	doc[i].addEventListener("click",function(){
		//console.log(this.textContent);//this is basically the identity which shows that which button triggers which event listener
		//this.style.color="white";							//this returns the whole element on which event has been trigerred
		switch(this.textContent){
			
			case 'w': var audio=new Audio("sounds/crash.mp3");
						audio.play();
						break;
			case 'a': var audio=new Audio("sounds/tom-1.mp3");
						audio.play();
						break;
			
			case 's':var audio=new Audio("sounds/tom-2.mp3");
						audio.play();
						break;
			
			case 'd': var audio=new Audio("sounds/snare.mp3");
						audio.play();
						break;
			
			case 'j':var audio=new Audio("sounds/tom-3.mp3");
						audio.play();
						break;
			case 'k':var audio=new Audio("sounds/kick-bass.mp3");
						audio.play();
						break;
			case 'l':var audio=new Audio("sounds/tom-4.mp3");
						audio.play();
						break;
			default :alert("no sound");
		}
	});
}

//forkeyboard press

document.addEventListener("keypress",function(event){
	makeSound(event.key);
							});

function makeSound(key){
	
	switch(key){
			
			case 'w': var audio=new Audio("sounds/crash.mp3");
						audio.play();
						break;
			case 'a': var audio=new Audio("sounds/tom-1.mp3");
						audio.play();
						break;
			
			case 's':var audio=new Audio("sounds/tom-2.mp3");
						audio.play();
						break;
			
			case 'd': var audio=new Audio("sounds/snare.mp3");
						audio.play();
						break;
			
			case 'j':var audio=new Audio("sounds/tom-3.mp3");
						audio.play();
						break;
			case 'k':var audio=new Audio("sounds/kick-bass.mp3");
						audio.play();
						break;
			case 'l':var audio=new Audio("sounds/tom-4.mp3");
						audio.play();
						break;
			default :alert("no sound");
					
		}
}






/*
document.addEventListener("keypress",function(event){
	makeSound(event.key);
							});

function makeSound(key){
	
	switch(key){
			
			case 'w': var audio=new Audio("sounds/crash.mp3");
						audio.play();
						break;
			case 'a': var audio=new Audio("sounds/tom-1.mp3");
						audio.play();
						break;
			
			case 's':var audio=new Audio("sounds/tom-2.mp3");
						audio.play();
						break;
			
			case 'd': var audio=new Audio("sounds/snare.mp3");
						audio.play();
						break;
			
			case 'j':var audio=new Audio("sounds/tom-3.mp3");
						audio.play();
						break;
			case 'k':var audio=new Audio("sounds/kick-bass.mp3");
						audio.play();
						break;
			case 'l':var audio=new Audio("sounds/tom-4.mp3");
						audio.play();
						break;
			default :alert("no sound");
					
		}
}
		

*/

/*
document.addEventListener("keypress",function(){
		alert("hey keyboard button pressed");
	});
*/
/*
for(var i=0;i<doc.length;i++){
	doc[i].addEventListener("click",IsClicked);
}

function IsClicked(e){
	var audio = new Audio("sounds/tom-1.mp3");
	audio.play();
}
*/
/*for w drum
var doc=document.querySelector(".w");
doc.addEventListener("click",isClicked);

function isClicked(){

	var audio = new Audio("sounds/crash.mp3");
	audio.play();
	
}

//for a drum

var adoc=document.querySelector(".a");
adoc.addEventListener("click",aIsClicked);

function aIsClicked(){
	var audio=new Audio("sounds/tom-1.mp3");
	audio.play();
}*/