
var random=Math.floor(Math.random()*6)+1;
//we will use this random number to select any random dice images


var randomDiceImage="dice"+random+".png"; //results in a dice image

var randomImageSource="images/"+randomDiceImage; // we will have to replace the image source attribute

var image1=document.querySelectorAll("img")[0];
image1.setAttribute("src",randomImageSource);


var random1=Math.floor(Math.random()*6)+1;
//we will use this random number to select any random dice images


var randomDiceImage1="dice"+random1+".png"; //results in a dice image

var randomImageSource1="images/"+randomDiceImage1; // we will have to replace the image source attribute

var image2=document.querySelectorAll("img")[1];
image2.setAttribute("src",randomImageSource1);


//changing the text content which will show who wins player 1 or player 2

if(random>random1){
	document.querySelector("h1").textContent="Player 1 wins";
	
}else if(random==random1){
	document.querySelector("h1").textContent="It's a Draw";
	
}
else{
	document.querySelector("h1").textContent="Player 2 wins";
	
}